% run the experiment given in the paper.


load brain
disp('brain experiment')

threshold

clear all

load angio
disp('angio experiment');

threshold
clear all

img = phantom(128);
disp('Shepp Logan experiment');
disp('This is the reason Shepp Logan works so well with TV!');

threshold


